<?php
include "db.php";
$uname = $_POST['uname'];
$pass = $_POST['pass'];
$q = "select count(sid) from student_login where semail = '".$uname."' and spass='".$pass."'";
$r = mysqli_query($con,$q);


$row = mysqli_fetch_array($r);
echo intval($row[0]);
if(intval($row[0])==1)
{
session_start();
$_SESSION['uid']=1;
header("Location:hh.php");
}
else if()
{
header('Location:login.php');
}
?> 	

   
