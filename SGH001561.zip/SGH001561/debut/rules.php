<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Rules</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="scss/main.css">
    <link rel="stylesheet" href="scss/skin.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
    <script src="./script/index.js"></script>
</head>

<body id="wrapper">

    <section id="top-header">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12 top-header-links">
                    <ul class="contact_links">
                        <li><i class="fa fa-phone"></i><a href="#">+91 8200298206</a></li>
                        <li><i class="fa fa-envelope"></i><a href="#">sutariyahit749@gmail.com</a></li>
                    </ul>
                </div>
            </div>
        </div>
        </div>

    </section>


    <section id="top_banner">
        <div class="banner">
            <div class="inner text-center">
                <h2>Rules & Regulations</h2>
            </div>
        </div>
    
	 <div class="page_info">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-sm-8 col-xs-6">
                        <h4>Rules & Regulations</h4>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-6" style="text-align:right;">Home<span class="sep"> / </span><span class="current">Contact</span></div>
                </div>
            </div>
        </div>
    </section>
	
	<p><b>&nbsp&nbsp&nbsp&nbsp&nbsp 1) Smoking, Alcohol & Narcotic consumption is strictly prohibited in and around the Hostel premises. Strict action will be taken against offenders.</br>
	  &nbsp&nbsp&nbsp&nbsp&nbsp 2) Strict adherence to the prescribed dress code is required. Decency in dressing & demeanor is a must.</br>
      &nbsp&nbsp&nbsp&nbsp&nbsp 3) Loitering in the Hostel campus during the class hours will not be appreciated.</br>
      &nbsp&nbsp&nbsp&nbsp&nbsp 4) The Management & Staff will not be responsible for personal belongings.</br>
      &nbsp&nbsp&nbsp&nbsp&nbsp 5) Late comers will be penalized.</br>
	  &nbsp&nbsp&nbsp&nbsp&nbsp 6) Students must keep the Campus & Rooms clean. Defacing walls, equipment, furniture etc., is strictly prohibited.</br>
      &nbsp&nbsp&nbsp&nbsp&nbsp 7) Birthday/Other Celebrations are strictly prohibited in Hostel.</br>
      &nbsp&nbsp&nbsp&nbsp&nbsp 8) Students must turn off all the electrical equipments & lights before leaving their rooms.</br>
      &nbsp&nbsp&nbsp&nbsp&nbsp 9) Students are not allowed to use electric stoves, heaters etc in rooms except in designated places.</br>
      &nbsp&nbsp&nbsp&nbsp&nbsp 10) Students are not allowed to organize any group activities in their room.</br>
	  &nbsp&nbsp&nbsp&nbsp&nbsp 11) Food will be served only in the designated Dining Hall(s) and only during the specified timings. Wasting food & water will not be encouraged.</br>
      &nbsp&nbsp&nbsp&nbsp&nbsp 12) All lights must be switched off before 11 pm in the rooms. Only study lamps are permitted.</br>
      &nbsp&nbsp&nbsp&nbsp&nbsp 13) Students are not allowed to use Mobile phones after 10 pm. Cell phones of those at fault will be confiscated.</br>
      &nbsp&nbsp&nbsp&nbsp&nbsp 14) Tipping of Wardens, Security Guards, Cleaning staff etc., is not permitted.</br>
      &nbsp&nbsp&nbsp&nbsp&nbsp 15) Visitors are allowed only in AV Room between: 4:30 p.m. and 6:30 p.m. Visitors are not allowed beyond the visiting area. No outside Guest\Students will be allowed inside the hostel.</br>
      &nbsp&nbsp&nbsp&nbsp&nbsp 16) Any complaints regarding electric equipment, plumbing etc., is required to be entered in the ‘Complaints Book’.</br>
      &nbsp&nbsp&nbsp&nbsp&nbsp 17) Students should not enter rooms of other students without permission.</br>
      &nbsp&nbsp&nbsp&nbsp&nbsp 18) Silence: Strict silence shall be observed in hostel from 11.00 pm to 5.30 am. Care should be taken at all times to ensure that music\loud talking is NOT audible outside the room.</br>
      &nbsp&nbsp&nbsp&nbsp&nbsp 19) Any manner of festivities and noise making\celebrations will not be entertained, which may cause disturbance to other inmates in the hostel premises.</br>
      &nbsp&nbsp&nbsp&nbsp&nbsp 20) Students during their stay in the hostel will be governed by the management rules.
</b></p>
	
	
	
	
	
    <section id="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                        <h4>Address</h4>
                        <hr/>
                        <p>Gyanmanjari Institute Of Technology,Survey NO.30,Near Iscon Eleven,sidsar road,Bhavnagar.
                        </p>
                        
                    </div>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                        <h4>Useful Links</h4>
                        <hr/>
                        <ul class="footer-links">
                                                       <li><a href="about.php">About Us</a></li>
                            <li><a href="features.php">Features</a></li>
                            <li><a href="facilities.php">Facilities</a></li>
               
                            <li><a href="login.php">Sign In</a></li>
                            <li><a href="registration.php">Sign Up</a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                        <h4>Community</h4>
                        <hr/>
                        <ul class="footer-links">
                            <li><a href="#">Blog</a></li>
                            <li><a href="#">Visit us on Facebook</a></li>
                            <li><a href="#">Follow us on Instagram</a></li>
                        </ul>
                    </div>
                </div>

                
            </div>
        </div>


    </section>

    <section id="bottom-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12 btm-footer-links">

                </div>
                <div class="col-md-6 col-sm-6 col-xs-12 copyright">
                    Developed by <a href="#">4th IT Students</a> designed by <a href="#">Designing Team</a>
                </div>
            </div>
        </div>
    </section>


</body>

</html>