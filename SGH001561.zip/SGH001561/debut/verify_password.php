<?php  
include "db.php";
$sid=$_GET['sid'];
$par_mo=$_POST['par_mo'];
$DOB=$_POST['date'];

$sql="select count(sid) from student where DOB = '".$DOB."' and par_mo='".$par_mo."' ";
$retrval=mysqli_query($con,$sql);
$row = mysqli_fetch_array($retrval);
echo intval($row[0]);
if(intval($row[0])==1)
{
	header("location:change_password.php");
}
else
{
	echo "Enter valid details";
	header("location:forget_password.php");
}

?>