<?php
include "db.php";
$fname=$_POST['fname'];
$f_occup=$_POST['fOccupation'];
$dob=$_POST['date'];
$gender=$_POST['Gender'];
$blood=$_POST['blood'];
$std_mo=$_POST['MobileNumber'];
$pare_mo=$_POST['Pmobile'];
$email=$_POST['EmailID'];
$address=$_POST['Address'];
$pincode=$_POST['PinCode'];
$institute=$_POST['Collage'];
$percentage=$_POST['percentage'];
$course=$_POST['course'];
$aadhar=$_POST['Aadhar'];
$result=$_POST['result1'];
$income=$_POST['income'];
$minority=$_POST['minority'];
$admission=$_POST['admission'];
$pic=$_POST['photo'];


	$sql="insert into student (full_name,f_occu,DOB,gender,blood_group,std_mo,par_mo,semail,address,pincode,std_clg,percentage,course,aadhar_no,result,income,minority,admission,pic)
		values('$fname','$f_occup','$dob','$gender','$blood','$std_mo','$pare_mo','$email','$address','$pincode','$institute','$percentage','$course','$aadhar','$result','$income','$minority','$admission','$pic')";
$retval=mysqli_query($con,$sql);
header("location:hh.php");
//if($retval)
{
	//echo "inserted successfully.";
}
//else
{
	//echo "not inserted successfully.";
}

?>