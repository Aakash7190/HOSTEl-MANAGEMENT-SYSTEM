<?php
include "db.php";
$lid=$_POST['lid'];
$fname=$_POST['fname'];
$f_date=$_POST['f_date'];
$t_date=$_POST['t_date'];
$Address=$_POST['Address'];
$reason=$_POST['reason'];
$mob_no=$_POST['mob_no'];
$pmobile=$_POST['pmobile'];

$sql="insert into leave_record (name,f_date,t_date,address,reason,mob_no,pmobile)
		values('$fname','$f_date','$t_date','$Address','$reason','$mob_no','$pmobile')";
$retval=mysqli_query($con,$sql);
if($retval)
{
header("location:wardenmessage.php");
}
else
{
	echo "not inserted";
}
?>