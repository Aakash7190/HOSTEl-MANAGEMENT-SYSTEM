<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>About</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="scss/main.css">
    <link rel="stylesheet" href="scss/skin.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
    <script src="./script/index.js"></script>

</head>

<body id="wrapper">

    <section id="top-header">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12 top-header-links">
                    <ul class="contact_links">
                        <li><i class="fa fa-phone"></i><a href="#">+91 9574140996</a></li>
                        <li><i class="fa fa-envelope"></i><a href="#">Aakashk7190@gmail.com</a></li>
                    </ul>
                </div>

            </div>
        </div>
        </div>

    </section>

    <header>
        <nav class="navbar navbar-inverse">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			  </button>
                    <a class="navbar-brand" href="#">
                        <h1>Hostel</h1><span>Management System</span></a>
                </div>
                <div id="navbar" class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="features.php">Features</a></li>
                        <li class="active"><a href="#about">About</a></li>
                        <li><a href="facilities.php">Facilities</a></li>
                       
                        
<?php 
session_start();						
if($_SESSION['uid']==0| $_SESSION['uid']=="")
{
?>
      <li><a href="login.php">Sign In</a></li>
<li><a href="registration.php">Sign Up</a></li><?php }
else if($_SESSION['uid']==2 || $_SESSION['uid']=="")
 {	?>

<li><a href="slideboard.php">Activities</a></li>
<li><a href="contact.php">Contact</a></li>
<li><a href="destroy_session.php">logout</a></li><?php }

else if($_SESSION['uid']==1 || $_SESSION['uid']=="")
{ ?>
<li><a href="wardenmessage.php">Take Leave</a></li>
	<li><a href="hh.php">Admission Form</a></li>
<li><a href="destroy_session.php">Logout</a></li>
<?php 
}
?> 
						
						
                    </ul>
                </div>
             
            </div>
        </nav>
      
    </header>
    <section id="top_banner">
        <div class="banner">
            <div class="inner text-center">
                <h2>About us</h2>
            </div>
        </div>
        <div class="page_info">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-sm-8 col-xs-6">
                        <h4>About</h4>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-6" style="text-align:right;">Home<span class="sep"> 	/ </span><span class="current"> About</span></div>
                </div>
            </div>
        </div>

        </div>
    </section>


    <section id="about-page-section-3">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-6 col-lg-7 text-align">
                    <div class="section-heading">
                        <h2>About <span>Us</span></h2>
                        <p class="subheading">What we do for the students in hostel</p>
                    </div>
                                  <ul class="aboutul">
                        <li> <i class="fa fa-check"></i>Our hostel has been running constantly since many years.</li>
                        <li> <i class="fa fa-check"></i>It not only inspires but also contributes to all round development of the student in wider perspective.</li>
                        <li> <i class="fa fa-check"></i>Our main and noble purpose is to provide accomodation to the students comming for higher studies.</li>
                        <li> <i class="fa fa-check"></i>We provide accomodation to all the students eho comes from rular areas.</li>
                        <li> <i class="fa fa-check"></i>Our hostel is in the estern part of the city.</li>
                        <li> <i class="fa fa-check"></i>Our hostel also provides scholarships to the needy students.</li>
                    </ul>
					<p>
					<br>The Hostel is situated in fully renovated historical building centrally located 
					near the very heart of the old town of Zadar. Within 5 min walk you can enjoy sunbathing 
					in public beach Kolovare, have fun in the most popular clubs and bars or take care of your 
					daily needs (bank, exchange office, shopping mall, grocery market...).</br>
                </p>
				<p>
				<br>Our hostel consist of 14 very originally decorated rooms, each personalized with a different style of it's own.
				This includes 43 possible beds. When we were developing our rooms, we put a lot of thought in their appearance.
				We have tried to match different tastes by giving all of our guests a piece of their own personality expressed through the accommodation that we offer.
                </br><br>All of the rooms listed above are equipped with air-conditioning and free Wi-Fi. Beds in all the rooms are provided with linen.
				</br>
				</p>
				<div class="row"><p class="subheading">To learn more about our rules and regulations colickon below button.</p>
				<a href="rules.php"><button type="button" class="btn btn-primary slide"><i class="fa fa-caret-right"></i></button></a></div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-6 col-lg-5">
                    <img height="" width="auto" src="img/21.jpg" class="attachment-full img-responsive" alt=""></br></br>
					   <img height="" width="auto" src="img/hostel.jpg" class="attachment-full img-responsive" alt="">
                </div>
            </div>
        </div>
    </section>

    <section id="team-member">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 xol-md-12 col-sm-12 col-xs-12">
                    <div class="section-heading text-center">
                        <h1>Our <span>Team</span></h1>
                        <p class="subheading">Our team is so much supportive to make student future bright. </p>
                    </div>
                    <div class="wpb_column vc_column_container col-md-3 col-sm-6 col-xs-6 block mybox">
                        <div class="vc_column-inner">
                            <div class="wpb_wrapper">
                                <div class="our-team main-info-below-image">
                                    <div class="our-team-inner">
                                        <div class="our-team-image">
                                            <img src="img/team-4.jpg" />
                                            <div class="qodef-circle-animate"></div>
                                            <div class="our-team-position-icon">
                                                <span class="qodef-icon-shortcode circle">
        			<i class="qodef-icon-simple-line-icon qodef-icon-element fa fa-cog"></i>
            </span>
                                            </div>
                                            <h6 class="q_team_position">Event Organisor</h6>
                                        </div>
                                        <div class="our-team-info">
                                            <div class="our-team-title-holder">
                                                <h5 class="our-team-name">Ram Puniyani</h5>
                                            </div>
                                            <div class='our-team-text-inner'>
                                                <div class='our-team-description'>
                                                    <p></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="wpb_column vc_column_container col-md-3 col-sm-6 col-xs-6 block mybox">
                        <div class="vc_column-inner">
                            <div class="wpb_wrapper">
                                <div class="our-team main-info-below-image">
                                    <div class="our-team-inner">
                                        <div class="our-team-image">
                                            <img src="img/team-4.jpg" />
                                            <div class="qodef-circle-animate"></div>
                                            <div class="our-team-position-icon">
                                                <span class="qodef-icon-shortcode circle">
        				<i class="qodef-icon-simple-line-icon fa fa-pencil qodef-icon-element"></i>
    					</span>
                                            </div>
                                            <h6 class="q_team_position">Administrator</h6>
                                        </div>
                                        <div class="our-team-info">
                                            <div class="our-team-title-holder">
                                                <h5 class="our-team-name">Manohar Vartak</h5>
                                            </div>
                                            <div class='our-team-text-inner'>
                                                <div class='our-team-description'>
                                                    <p></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="wpb_column vc_column_container col-md-3 col-sm-6 col-xs-6 block mybox">
                        <div class="vc_column-inner ">
                            <div class="wpb_wrapper">
                                <div class="our-team main-info-below-image">
                                    <div class="our-team-inner">
                                        <div class="our-team-image">
                                            <img src="img/team-4.jpg" />
                                            <div class="qodef-circle-animate"></div>
                                            <div class="our-team-position-icon">
                                                <span class="qodef-icon-shortcode circle">        
        					<i class="qodef-icon-simple-line-icon fa fa-hashtag qodef-icon-element"></i>
            		</span>
                                            </div>
                                            <h6 class="q_team_position">Rector</h6>
                                        </div>
                                        <div class="our-team-info">
                                            <div class="our-team-title-holder">
                                                <h5 class="our-team-name">N K Nayak</h5>
                                            </div>
                                            <div class='our-team-text-inner'>
                                                <div class='our-team-description'>
                                                    <p></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="wpb_column vc_column_container col-md-3 col-sm-6 col-xs-6 block mybox">
                        <div class="vc_column-inner ">
                            <div class="wpb_wrapper">
                                <div class="our-team main-info-below-image">
                                    <div class="our-team-inner">
                                        <div class="our-team-image">
                                            <img src="img/team-4.jpg" />
                                            <div class="qodef-circle-animate"></div>
                                            <div class="our-team-position-icon">
                                                <span class="qodef-icon-shortcode circle ">
						        <i class="qodef-icon-simple-line-icon fa fa-wrench qodef-icon-element" ></i>
			            </span>
                                            </div>
                                            <h6 class="q_team_position">Hostel Wardon</h6>
                                        </div>
                                        <div class="our-team-info">
                                            <div class="our-team-title-holder">
                                                <h5 class="our-team-name">S H Patel</h5>
                                            </div>
                                            <div class='our-team-text-inner'>
                                                <div class='our-team-description'>
                                                    <p></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <section id="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                        <h4>Address</h4>
                        <hr/>
                        <p>Gyanmanjari Institute Of Technology,
						Survey NO.30,Near Iscon Eleven,
						 Sidsar road,Bhavnagar.
                        </p>
                        
                    </div>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                        <h4>Useful Links</h4>
                        <hr/>
                        <ul class="footer-links">
                            <li><a href="index.php">Home</a></li>
                            <li><a href="features.php">Features</a></li>
                            <li><a href="about.php">About</a></li>
                            <li><a href="facilities.php">Facilities</a></li>
                            <li><a href="login.php">Sign In</a></li>
                            <li><a href="registration.php">Sign Up</a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                        <h4>Community</h4>
                        <hr/>
                        <ul class="footer-links">
                            <li><a href="#">Blog</a></li>
                            <li><a href="#">Visit on Facebook</a></li>
                            <li><a href="#">Follow us on Instagram</a></li>
                        </ul>
                    </div>
                </div>

               
            </div>
        </div>


    </section>

    <section id="bottom-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12 btm-footer-links">
                    <a href="#">Privacy Policy</a>
                    <a href="#">Terms of Use</a>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12 copyright">
                    Developed by <a href="#">4th IT Students</a> designed by <a href="#">Designing Team</a>
                </div>
            </div>
        </div>
    </section>





</body>

</html>