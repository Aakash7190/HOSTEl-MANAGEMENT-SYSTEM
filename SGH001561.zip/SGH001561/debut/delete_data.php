<?php 
$sid=$_GET['sid'];

include "db.php";
$sql="DELETE FROM student where sid='$sid'";
$query= mysqli_query($con, $sql);

if($query)
{
	header("location:admintable.php");
}
else
{
	echo "not deleted";
}
?>