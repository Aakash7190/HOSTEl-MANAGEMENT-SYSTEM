<?php
include "db.php";
?>

<!DOCTYPE html>
<html>

<head>
<script>
function SUBMIT(){
	alert("Your message is Submitted Successfully!");
}
</script>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Contact</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="scss/main.css">
    <link rel="stylesheet" href="scss/skin.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
    <script src="./script/index.js"></script>
</head>

<body id="wrapper">

    <section id="top-header">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12 top-header-links">
                    <ul class="contact_links">
                        <li><i class="fa fa-phone"></i><a href="#">+91 9574140996</a></li>
                        <li><i class="fa fa-envelope"></i><a href="#">Aakashk7190@gmail.com</a></li>
                    </ul>
                </div>

            </div>
        </div>
        </div>

    </section>

    <header>
        <nav class="navbar navbar-inverse">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			  </button>
                    <a class="navbar-brand" href="#">
                        <h1>Hostel</h1><span>Management System</span></a>
                </div>
                <div id="navbar" class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                        <li><a href="admintable.php">Student data</a></li>
                        <li class="active"><a href="admin_feedback.php">Message</a></li>
                        
                       
                      
                       <?php
session_start();			   
if($_SESSION['uid']==0)
{
?>
      <li><a href="login.php">Sign In</a></li>
<li><a href="registration.php">Sign Up</a></li><?php }
 else 
 {	?>

<li><a href="destroy_session.php">logout</a></li><?php } ?>
                    </ul>
                </div>
                <!--/.nav-collapse -->
            </div>
        </nav>
        <!--/.nav-ends -->
    </header>
    <section id="top_banner">
        <div class="banner">
            <div class="inner text-center">
                <h2>Feedback From Parents</h2>
            </div>
        </div>
        <div class="page_info">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-sm-8 col-xs-6">
                        <h4>Message</h4>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-6" style="text-align:right;">Admin<span class="sep"> / </span><span class="current">Message</span></div>
                </div>
            </div>
        </div>

        </div>
    </section>
    
	

	
	
		
		
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<div class="panel panel-default">
							<div class="panel-heading">All Room Details</div>
							<div class="panel-body">
								<div class="row"><div class="col-sm-6"></div><div class="col-sm-6"></div><table id="zctb" class="display table table-striped table-bordered table-hover dataTable" cellspacing="0" width="100%" role="grid" aria-describedby="zctb_info" style="width: 100%;">
									<thead>
										<tr role="row"><th class="sorting_asc" tabindex="0" aria-controls="zctb" rowspan="1" colspan="1" aria-label="Sno.: activate to sort column descending" style="width: 31px;" aria-sort="ascending">Name</th>
										<th class="sorting" tabindex="0" aria-controls="zctb" rowspan="1" colspan="1" aria-label="Student Name: activate to sort column ascending" style="width:98px;">Email</th>
										<th class="sorting" tabindex="0" aria-controls="zctb" rowspan="1" colspan="1" aria-label="Reg no: activate to sort column ascending" style="width: 48px;">Phone</th>
										<th class="sorting" tabindex="0" aria-controls="zctb" rowspan="1" colspan="1" aria-label="Contact no : activate to sort column ascending" style="width: 57px;">Subject </th>
										<th class="sorting" tabindex="0" aria-controls="zctb" rowspan="1" colspan="1" aria-label="Staying From : activate to sort column ascending" style="width: 51px;">Message</th>
										
									</thead>
									<tbody>

<?php include "db.php";
$sql="select * from contact ORDER BY cid";
$retval=mysqli_query($con,$sql);	 
while($row=mysqli_fetch_array($retval))
{
	$cid=$row['cid'];
	$name=$row['name'];
	$email=$row['email'];
	$mobile_no=$row['mobile_no'];
	$subject=$row['subject'];
	$message=$row['message'];
?>									
<tr role="row" class="odd">
<td><?php echo $name; ?></td>
<td><?php echo $email; ?></td>
<td><?php echo $mobile_no; ?></td>
<td><?php echo $subject; ?></td>
<td><?php echo $message; ?></td>
</tr>
<?php } ?>	
								</tbody>
                                  </table>
								</div>
							</div>
						</div>		
	</div>
	</div>
	</div>
	
	
	
	
	
    
</body>

</html>