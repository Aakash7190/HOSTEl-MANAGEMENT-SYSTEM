<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Features</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="scss/main.css">
    <link rel="stylesheet" href="scss/skin.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
    <script src="./script/index.js"></script>
</head>

<body id="wrapper">

    <section id="top-header">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12 top-header-links">
                    <ul class="contact_links">
                        <li><i class="fa fa-phone"></i><a href="#">+91 848 594 5080</a></li>
                        <li><i class="fa fa-envelope"></i><a href="#">sales@aspiresoftware.in</a></li>
                    </ul>
                </div>
 
            </div>
        </div>
        </div>

    </section>

    <header>
        <nav class="navbar navbar-inverse">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			  </button>
                    <a class="navbar-brand" href="#">
                        <h1>Hostel</h1><span>Management System<span></a>
                </div>
                <div id="navbar" class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                        <li><a href="index.php">Home</a></li>
                        <li class="active"><a href="#about">Features</a></li>
                        <li><a href="about.php">About</a></li>
                        <li><a href="facilities.php">Facilities</a></li>
                     
                      
                        
                                                 <?php 
session_start();						
if($_SESSION['uid']==0| $_SESSION['uid']=="")
{
?>
      <li><a href="login.php">Sign In</a></li>
<li><a href="registration.php">Sign Up</a></li><?php }
else if($_SESSION['uid']==2 || $_SESSION['uid']=="")
 {	?>

<li><a href="slideboard.php">Activities</a></li>
<li><a href="contact.php">Contact</a></li>
<li><a href="destroy_session.php">logout</a></li><?php }

else if($_SESSION['uid']==1 || $_SESSION['uid']=="")
{ ?>
<li><a href="wardenmessage.php">Take Leave</a></li>
	<li><a href="hh.php">Admission Form</a></li>
<li><a href="destroy_session.php">Logout</a></li>
<?php 
}
?> 
                    </ul>
                </div>
           
            </div>
        </nav>
       
    </header>







    <section id="features-page">
        <div class="subsection1">
            <div class="container">
                <div class="section-heading text-center">
                    <h1>Our <span>Features</span></h1>
                    <p class="subheading">Lorem ipsum dolor sit amet sit legimus copiosae instructior ei ut.</p>
                </div>
                <div class="col sm_12">
                    <div class="col-sm-4 wpb_column block">
                        <div class="wpb_wrapper">
                            <div class="flip">
                                <div class="iconbox iconbox-style icon-color card clearfix">
                                    <div class="face front">
                                        <table>
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <i class="fa fa-laptop boxicon"></i>
                                                        <h3>100% Responsive</h3>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="iconbox-box2 face back">
                                        <table>
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <h3>100% Responsive</h3>
                                                        <p>We are continuously working to give you our 100% response at any point of time.</p>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4 wpb_column block">
                        <div class="wpb_wrapper">
                            <div class="flip">
                                <div class="iconbox  iconbox-style icon-color card clearfix">
                                    <div class="iconbox-box1 face front">
                                        <table>
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <i class="fa fa-bullhorn boxicon"></i>
                                                        <h3>Easy to get admit</h3>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="iconbox-box2 face back">
                                        <table>
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <h3>Easy to get admit</h3>
                                                        <p>Those students who want to take admission in our hostel is getting easily by some following steps and providing credential details about him self.</p>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4 wpb_colum block">
                        <div class="wpb_wrapper">
                            <div class="flip">
                                <div class="iconbox  iconbox-style icon-color card clearfix">
                                    <div class="iconbox-box1 face front">
                                        <table>
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <i class="fa fa-support boxicon"></i>
                                                        <h3>24x7 Online support</h3>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="iconbox-box2 face back">
                                        <table>
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <h3>24x7 Online support</h3>
                                                        <p>Contact 24online support for any requirements or query regarding your admission process. Strong support team to support your network 24x7 365 days proactively.</p>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="subsection2">
            <div class="container">
                <div class="col-xs-12 col-sm_12 col-md-12 col-lg-12 left">
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 wpb_column">
                        <div class="wpb_wrapper">
                            <h3>We really love what we do & our work on every project truly reflects that.</h3>
                            <hr>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 wpb_column block">
                        <div class="wpb_wrapper">
                            <div class="iconbox iconbox-style-2 icon-color clearfix">
                                <div class="iconbox-icon">
                                    <i class="fa fa-lightbulb-o sl-layers boxicon"></i>
                                </div>
                                <div class="iconbox-content">
                                    <h4>IDEA</h4>
                                    <p>To provide a computerized process that is stress free, reliable and quick through the use of PHP computer programming language and MySQL database application to both the students and the staff in charge of the registration and hostel management processes.</p>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 wpb_column">
                        <div class="wpb_wrapper">
                            <div class="iconbox iconbox-style-2 icon-color clearfix">
                                <!-- icon-color-greyscale -->
                                <div class="iconbox-icon">
                                    <i class="fa fa-cloud-download sl-badge boxicon"></i>
                                </div>
                                <div class="iconbox-content">
                                    <h4>CONCEPT</h4>
                                    <p>Our concept is about to provide all essential facilities to student for a hostel like booking a room etc....etc..</p>
                                </div>
                            </div>
                            <div class="spacer"></div>
                            <div class="iconbox iconbox-style-2 icon-color clearfix">
                                <div class="iconbox-icon">
                                    <i class="fa fa-cog sl-check boxicon"></i>
                                </div>
                                <div class="iconbox-content nomargin">
                                    <h4>GET UPDATED</h4>
                                    <p>The main thing is that student's parents will get update notification via SMS.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="subsection3" style=" overflow-x:hidden;">

            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-6 col-xs-12 left-section">
                        <div class="subfeature">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <h1><span>Services that </span>we provide.</h1>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12 right-section right-background">
                        <div class="subfeature">
                            <div class="featureblock">
                                <div class="col-md-2 col-xs-2 icon"><i class="fa fa-laptop feature_icon"></i></div>
                                <div class="col-md-10 col-xs-10">
                                    <h4>100% Responsive</h4>
                                    <p>We are continuously working to give you our 100% response at any point of time.
									</div>
                            </div>
                            <div class="featureblock">
                                <div class="col-md-2 col-xs-2 icon"><i class="fa fa-bullhorn feature_icon"></i></div>
                                <div class="col-md-10 col-xs-10">
                                    <h4>Easy to get admit</h4>
                                    <p>Those students who want to take admission in our hostel is getting easily by some following steps and providing credential details about him self.</p>
                                </div>
                            </div>
                            <div class="featureblock nomargin">
                                <div class="col-md-2 col-xs-2 icon"><i class="fa fa-support feature_icon"></i></div>
                                <div class="col-md-10 col-xs-10">
                                    <h4>24x7 Online support</h4>
                                    <p>Contact 24online support for any requirements or query regarding your admission process. Strong support team to support your network 24x7 365 days proactively.</</p>

                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>

      
    </section>

    <section id="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                        <h4>Address</h4>
                        <hr/>
                        <p>Gyanmanjari Institute Of Technology,Survey NO.30,Near Iscon Eleven,sidsar road,Bhavnagar.
                        </p>
                        
                    </div>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                        <h4>Useful Links</h4>
                        <hr/>
                        <ul class="footer-links">
                                                        <li><a href="about.php">About Us</a></li>
                            <li><a href="features.php">Features</a></li>
                            <li><a href="facilities.php">Facilities</a></li>
               
                            <li><a href="login.php">Sign In</a></li>
                            <li><a href="registration.php">Sign Up</a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                        <h4>Community</h4>
                        <hr/>
                        <ul class="footer-links">
                            <li><a href="#">Blog</a></li>
                            <li><a href="#">Visit us on Facebook</a></li>
                            <li><a href="#">Follow us on Instagram</a></li>
                        </ul>
                    </div>
                </div>

                
            </div>
        </div>


    </section>

    <section id="bottom-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12 btm-footer-links">
                    <a href="#">Privacy Policy</a>
                    <a href="#">Terms of Use</a>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12 copyright">
                    Developed by <a href="#">4th IT Students</a> designed by <a href="#">Designing Team</a>
                </div>
            </div>
        </div>
    </section>


</body>

</html>