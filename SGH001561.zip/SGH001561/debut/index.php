<!DOCTYPE html>
<html>
<?php

include "db.php";

?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Home</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="scss/main.css">
    <link rel="stylesheet" href="scss/skin.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
    <script src="./script/index.js"></script>
</head>

<body id="wrapper">

    <section id="top-header">
        <div class="container">
            <div class="row">
                <div class="col-md-7 col-sm-7 col-xs-7 top-header-links">
                    <ul class="contact_links">
                        <li><i class="fa fa-phone"></i><a href="#">+91 974140996</a></li>
                        <li><i class="fa fa-envelope"></i><a href="#">Aakashk7190@gmail.com</a></li>
                    </ul>
                </div>
    
            </div>
        </div>
        </div>

    </section>

    <header>
        <nav class="navbar navbar-inverse">
            <div class="container">
                <div class="row">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			  </button>
                        <a class="navbar-brand" href="#">
                            <h1>Hostel</h1><span>Management System</span></a>
                    </div>
                    <div id="navbar" class="collapse navbar-collapse navbar-right">
                        <ul class="nav navbar-nav">
                            <li class="active"><a href="#">Home</a></li>
                            <li><a href="features.php">Features</a></li>
                            <li><a href="about.php">About</a></li>
                            <li><a href="facilities.php">Facilities</a></li>
							
<?php 
session_start();						
if($_SESSION['uid']==0 || $_SESSION['uid']=="")
{
?>
      <li><a href="login.php">Sign In</a></li>
<li><a href="registration.php">Sign Up</a></li><?php }
else if($_SESSION['uid']==1 || $_SESSION['uid']=="")
 {	?>
<li><a href="wardenmessage.php">Take Leave</a></li>
	<li><a href="hh.php">Admission Form</a></li>
<li><a href="destroy_session.php">Logout</a></li>
<?php }

else if($_SESSION['uid']==2 || $_SESSION['uid']=="")
{ ?>

<li><a href="slideboard.php">Activities</a></li>
<li><a href="contact.php">Contact</a></li>
<li><a href="destroy_session.php">logout</a></li>
<?php 
}
?> 
                        </ul>
                    </div>
                   
                </div>
            </div>
        </nav>
    </header>
    


  
    <div id="myCarousel" class="carousel slide">
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>

       
        <div class="carousel-inner">
            <div class="item active">
                <div class="fill" style="background-image:url('img/hostel.jpg');"></div>
                <div class="carousel-caption slide-up">
                    <h1 class="banner_heading">Providing The <span></span> Best Hostel</h1>
                    <p class="banner_txt">The hostel is having the best facilities all over the city. The students feels better with us.</p>
                    
                </div>
            </div>

            <div class="item">
                <div class="fill" style="background-image:url('img/hostel1.jpg');"></div>
                <div class="carousel-caption slide-up">
                    <h1 class="banner_heading">Providing The <span></span>2 star rooms</h1>
                    <p class="banner_txt">The room consists of the 4 beds in each rooms. The size of the room is 25X25 ft with many other facilities.</p>
                    
                </div>
            </div>

            <div class="item">
                <div class="fill" style="background-image:url('img/hostel2.jpg');"></div>
                <div class="carousel-caption slide-up">
                    <h1 class="banner_heading">Hostel with <span></span>Best Infrastructure</h1>
                    <p class="banner_txt">The hostel is having the 4 floors and 3 blocks. Each floor is consists of 20 rooms and rest area.</p>
                    
                </div>
            </div>
        </div>

     

        <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev"> <i class="fa fa-angle-left" aria-hidden="true"></i>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next"> <i class="fa fa-angle-right" aria-hidden="true"></i>
            <span class="sr-only">Next</span>
        </a>

    </div>

    <section id="features">
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-xs-12 block">
                    <div class="col-md-2 col-xs-2"><i class="fa fa-laptop feature_icon"></i></div>
                    <div class="col-md-10 col-xs-10">
                        <h4>100% Responsive</h4>
                        <p>We are continuously working to give you our 100% response at any point of time.</p>
                       
                    </div>
                </div>
                <div class="col-md-4 col-xs-12 block">
                    <div class="col-md-2 col-xs-2"><i class="fa fa-bullhorn feature_icon"></i></div>
                    <div class="col-md-10 col-xs-10">
                        <h4>Easy to get admit</h4>
                        <p>Those students who want to take admission in our hostel is getting easily by some following steps and providing credential details about him self. </p>
                       
                    </div>
                </div>
                <div class="col-md-4 col-xs-12 block">
                    <div class="col-md-2 col-xs-2"><i class="fa fa-support feature_icon"></i></div>
                    <div class="col-md-10 col-xs-10">
                        <h4>24x7 Online Support</h4>
                        <p>Contact 24online support for any requirements or query regarding your admission process. Strong support team to support your network 24x7 365 days proactively.</p>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section id="about">
        <div class="image-holder col-lg-6 col-md-6 col-sm-6 col-xs-12 pull-left">
            <div class="background-imgholder">
                <img src="img/21.jpg" alt="about" class="img-responsive" style="height:700px;" />
            </div>
        </div>

        <div class="container-fluid">

            <div class="col-md-7 col-md-offset-5 col-sm-8 col-sm-offset-2 col-xs-12 text-inner ">
                <div class="text-block">
                    <div class="section-heading">
                        <h1>ABOUT <span>US</span></h1>
                        <p class="subheading">What we do for the students in hostel</p>
                    </div>

                    <ul class="aboutul">
                        <li> <i class="fa fa-check"></i>Our hostel has been running constantly since many years.</li>
                        <li> <i class="fa fa-check"></i>It not only inspires but also contributes to all round development of the student in wider perspective.</li>
                        <li> <i class="fa fa-check"></i>Our main and noble purpose is to provide accomodation to the students comming for higher studies.</li>
                        <li> <i class="fa fa-check"></i>We provide accomodation to all the students eho comes from rular areas.</li>
                        <li> <i class="fa fa-check"></i>Our hostel is in the estern part of the city.</li>
                        <li> <i class="fa fa-check"></i>Our hostel also provides scholarships to the needy students.</li>
                    </ul>

                                   </div>
            </div>
        </div>
    </section>


   


    

    <section id="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                        <h4>Address</h4>
                        <hr/>
                        <p>Gyanmanjari Institute Of Technology,Survey NO.30,Near Iscon Eleven,sidsar road,Bhavnagar.
                        </p>
               
                    </div>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                        <h4>Useful Links</h4>
                        <hr/>
                        <ul class="footer-links">
                                                       <li><a href="about.php">About Us</a></li>
                            <li><a href="features.php">Features</a></li>
                            <li><a href="facilities.php">Facilities</a></li>
               
                            <li><a href="login.php">Sign In</a></li>
                            <li><a href="registration.php">Sign Up</a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                        <h4>Community</h4>
                        <hr/>
                        <ul class="footer-links">
						<li><a href="#">Blog</a></li>
                            <li><a href="#">Visit Us on Facebook</a></li>
                            <li><a href="#">Follow us on Instagram</a></li>
                            
                       
						</ul>
                    </div>
                </div>

                
            </div>
        </div>


    </section>

    <section id="bottom-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12 btm-footer-links">
                    <a href="#">Privacy Policy</a>
                    <a href="#">Terms of Use</a>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12 copyright">
                    Developed by <a href="#">4th IT Students</a> designed by <a href="#">Designing Team</a>
                </div>
            </div>
        </div>
    </section>



</html>