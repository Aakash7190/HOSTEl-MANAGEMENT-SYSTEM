<?php 
include "db.php";
$f_name=$_POST['fname'];
$l_name=$_POST['lname'];
$phone=$_POST['phone'];
$email=$_POST['email'];
$pass=$_POST['password'];

$sql="Insert into student_login (f_name,l_name,phone_no,semail,spass)
					values('$f_name','$l_name','$phone','$email','$pass')";
$query=mysqli_query($con,$sql);

if($query)
{
	echo "success";
	header("location:login.php");
}
else
{
	echo "not";
}
?>