<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>FAQ</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="scss/main.css">
    <link rel="stylesheet" href="scss/skin.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
    <script src="./script/index.js"></script>


</head>

<body id="wrapper">

    <section id="top-header">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12 top-header-links">
                    <ul class="contact_links">
                        <li><i class="fa fa-phone"></i><a href="#">+91 9574140996</a></li>
                        <li><i class="fa fa-envelope"></i><a href="#">Aakashk7190@gmail.com</a></li>
                    </ul>
                </div>
    
            </div>
        </div>
        </div>

    </section>

    <header>
        <nav class="navbar navbar-inverse">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			  </button>
                    <a class="navbar-brand" href="#">
                        <h1>Hostel</h1><span>Management System</span></a>
                </div>
                <div id="navbar" class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="features.php">Features</a></li>
                        <li><a href="#about">About</a></li>
                        <li><a href="facilities.php">Facilities</a></li>
                        <li class="active"><a href="faq.php">FAQ</a></li>

                       
<?php 
session_start();						
if($_SESSION['uid']==0 || $_SESSION['uid']=="")
{
?>
      <li><a href="login.php">Sign In</a></li>
<li><a href="registration.php">Sign Up</a></li><?php }
 else 
 {	?>
<li><a href="hh.php">Admission Form</a></li>
<li><a href="destroy_session.php">logout</a></li><?php } ?>
                    </ul>
                </div>
              
            </div>
        </nav>
      
    </header>

    <section id="top_banner">
        <div class="banner">
            <div class="inner text-center">
                <h2>Payment Details</h2>
            </div>
        </div>
        <div class="page_info">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-sm-8 col-xs-6">
                        <h4>Payment Details</h4>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-6" style="text-align:right;">Home<span class="sep"> 	/ </span><span class="current"> Payment Details</span></div>
                </div>
            </div>
        </div>

        </div>
    </section>


    <section id="faq">
        <div class="titlebar">
            <div class="container">
 <div class="form-group">
<label class="col-sm-2 control-label">Registration ID:<span style="color:red">*</span></label>
<div class="col-sm-8">
<input type="text" name="fname" class="form-control" readonly>
</div>
</div>

<br></br>
<div class="form-group">
<label class="col-sm-2 control-label">Student Name:<span style="color:red">*</span></label>
<div class="col-sm-8">
<input type="text" name="fOccupation" class="form-control" readonly>
</div>
</div>
<br></br>
<div class="form-group">
<label class="col-sm-2 control-label">Food Status:<span style="color:red">*</span></label>
<div class="col-sm-8">
<td>
<input type="radio" name="food" value="with food" >
With food
<input type="radio" name="food" value="without food" >
Without food
<br></br>
</td>
<div></div>
</div>

<br></br>
<div class="form-group">
<label class="col-sm-2 control-label">Physical Activities:<span style="color:red">*</span></label>
<div class="col-sm-8">
<td>
<input type="radio" name="physical" value="yes" >
Yes
<input type="radio" name="physical" value="no" >
No
<br></br>
</td>
</div>





</div>
</div>

         </div>
        </div>
    </section>






    <section id="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                        <h4>Address</h4>
                        <hr/>
                        <p>Gyanmanjari Institute Of Technology,Survey NO.30,Near Iscon Eleven,sidsar road,Bhavnagar.
                        </p>
                        
                    </div>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                        <h4>Useful Links</h4>
                        <hr/>
                        <ul class="footer-links">
                                                        <li><a href="about.php">About Us</a></li>
                            <li><a href="features.php">Features</a></li>
                            <li><a href="facilities.php">Facilities</a></li>
               
                            <li><a href="login.php">Sign In</a></li>
                            <li><a href="registration.php">Sign Up</a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                        <h4>Community</h4>
                        <hr/>
                        <ul class="footer-links">
                            <li><a href="#">Blog</a></li>
                            <li><a href="https://facebook.com">Visit us on Facebook</a></li>
                            <li><a href="https://instagram.com">Follow us on Instagram</a></li>
                        </ul>
                    </div>
                </div>

                <v>
            </div>
        </div>


    </section>

    <section id="bottom-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12 btm-footer-links">
                    <a href="#">Privacy Policy</a>
                    <a href="#">Terms of Use</a>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12 copyright">
                    Developed by <a href="#">4 th IT Students</a> designed by <a href="#">Designing Team</a>
                </div>
            </div>
        </div>
    </section>



</body>

</html>