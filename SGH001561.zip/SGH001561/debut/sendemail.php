<?php
include "db.php";
$name=$_POST['name'];
$email=$_POST['email'];
$mobile_no=$_POST['mobile_no'];
$subject=$_POST['subject'];
$message=$_POST['message'];

$sql="insert into contact (name,email,mobile_no,subject,message) values ('$name','$email','$mobile_no','$subject','$message')";
$retval=mysqli_query($con,$sql);

if($retval)
{
header("location:contact.php");
}
else
{
	echo("Not successful");
}
?>