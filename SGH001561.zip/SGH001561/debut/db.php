<?php

$con = mysqli_connect('localhost','root','','hostel');
if(!$con)
{
echo "Failed";
}
?>