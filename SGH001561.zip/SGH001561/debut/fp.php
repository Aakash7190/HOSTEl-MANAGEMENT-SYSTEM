<?php
session_start();
include"db.php";
?>
<script language="javascript" type="text/javascript">
function f2()
{
window.close();
}
function f3()
{
window.print();
}
</script>

<html >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Student Full Information</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<link href="hostel.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0">
<?php include "db.php";
	$sid=$_GET['sid'];
$sql="select * from student  ORDER BY sid";
$retval=mysqli_query($con,$sql);
if($row=mysqli_fetch_array($retval))
{
	
	$sid=$row['sid'];
	$full_name=$row['full_name'];
	$gender=$row['gender'];
	$semail=$row['semail'];
	$std_mo=$row['std_mo'];
	$par_mo=$row['par_mo'];
	$address=$row['address'];
	$pincode=$row['pincode'];	
	$f_occu=$row['f_occu'];
	$DOB=$row['DOB'];
	$blood_group=$row['blood_group'];
	$std_clg=$row['std_clg'];
	$course=$row['course'];
	$aadhar_no=$row['aadhar_no'];
	$result=$row['result'];
	$income=$row['income'];
	$minority=$row['minority'];
	$admission=$row['admission'];
	$pic=$row['pic'];
?>
	<table align="center" size="100%">
	<tr><td>Full Name:</td><td><?php echo $full_name; ?></td></tr>
	<tr><td>Father Occupation:</td><td><?php echo $f_occu; ?></td></tr>
	<tr><td>Birth Date:</td><td><?php echo $DOB; ?></td></tr>
    <tr><td>Gender:</td><td><?php echo $gender; ?></td></tr>
	<tr><td>Blood Group:</td><td><?php echo $blood_group; ?></td></tr>
	<tr><td>Student Number:</td><td><?php echo $std_mo; ?></td></tr>
	<tr><td>Gurdian Number:</td><td><?php echo $par_mo; ?></td></tr>
	<tr><td>Email:</td><td><?php echo $semail; ?></td></tr>
	<tr><td>Address:</td><td><?php echo $address; ?></td></tr>
	<tr><td>Pincode:</td><td><?php echo $pincode; ?></td></tr>
	<tr><td>College:</td><td><?php echo $std_clg; ?></td></tr>
	<tr><td>Course:</td><td><?php echo $course; ?></td></tr>
	<tr><td>Aadhar No:</td><td><?php echo $aadhar_no; ?></td></tr>
	
	<tr><td>Result:</td><td><img src=<?php $result ?> </td></tr>
	
	<tr><td>Income:</td><td><?php echo $income; ?></td></tr>
	
	<tr><td>Minority:</td><td><?php echo $minority; ?></td></tr>
	
	<tr><td>Admission:</td><td><?php echo $admission; ?></td></tr>
	
	<tr><td>Photo:</td><td><?php echo $pic; ?></td></tr>
	
	</table>
<?php }  ?>
             </table></td>
             </tr>
            </table></td>
            </tr>
              </table></td>
  </tr>

           
 

    </table></td>
  </tr>

 
  <tr>
    <td colspan="2" align="right" ><form id="form1" name="form1" method="post" action="">
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="14%">&nbsp;</td>
          <td width="35%" class="comb-value"><label>
            <input name="Submit" type="submit" class="txtbox4" value="Prints this Document " onClick="return f3();" />
          </label></td>
          <td width="3%">&nbsp;</td>
          <td width="26%"><label>
            <input name="Submit2" type="submit" class="txtbox4" value="Close this document " onClick="return f2();"  />
          </label></td>
          <td width="8%">&nbsp;</td>
          <td width="14%">&nbsp;</td>
        </tr>
      </table>
        </form>    </td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
</table>
</body>
</html>