<!DOCTYPE html>
<html>
<head>
<style>
body {font-family: Arial, Helvetica, sans-serif;}

.modal {
  display: none; 
  position: fixed;
  z-index: 1; 
  padding-top: 100px;
  left: 0;
  top: 0;
  width: 100%; 
  height: 100%; 
  overflow: auto; 
  background-color: rgb(0,0,0);
  background-color: rgba(0,0,0,0.4); 
}

.modal-content {
  position: relative;
  background-color: #fefefe;
  margin: auto;
  padding: 0;
  border: 1px solid #888;
  width: 80%;
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
  -webkit-animation-name: animatetop;
  -webkit-animation-duration: 0.4s;
  animation-name: animatetop;
  animation-duration: 0.4s
}

@-webkit-keyframes animatetop {
  from {top:-300px; opacity:0} 
  to {top:0; opacity:1}
}

@keyframes animatetop {
  from {top:-300px; opacity:0}
  to {top:0; opacity:1}
}

.close {
  color: white;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}

.modal-header {
  padding: 2px 16px;
  background-color: grey;
  color: white;
}

.modal-body {padding: 2px 16px;}

</style>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>FAQ</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="scss/main.css">
    <link rel="stylesheet" href="scss/skin.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
    <script src="./script/index.js"></script>

<script language="javascript" type="text/javascript">
var popUpWin=0;
function popUpWindow(URLStr, left, top, width, height)
{
 if(popUpWin)
{
if(!popUpWin.closed) popUpWin.close();
}
popUpWin = open(URLStr,'popUpWin', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,copyhistory=yes,width='+510+',height='+430+',left='+left+', top='+top+',screenX='+left+',screenY='+top+'');
}
</script>
</head>

<body id="wrapper">

    <section id="top-header">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12 top-header-links">
                    <ul class="contact_links">
                        <li><i class="fa fa-phone"></i><a href="#">+91 9574140996</a></li>
                        <li><i class="fa fa-envelope"></i><a href="#">Aakashk7190@gmail.com</a></li>
                    </ul>
                </div>
          
            </div>
        </div>
        </div>

    </section>

    <header>
        <nav class="navbar navbar-inverse">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			  </button>
                    <a class="navbar-brand" href="#">
                        <h1>Hostel</h1><span>Management System</span></a>
                </div>
                <div id="navbar" class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                         <li class="active"><a href="admintable.php">Student data</a></li>
                        <li><a href="admin_feedback.php">Message</a></li>
                        
                       
                      
                       <?php
session_start();			   
if($_SESSION['uid']==0)
{
?>
      <li><a href="login.php">Sign In</a></li>
<li><a href="registration.php">Sign Up</a></li><?php }
 else 
 {	?>

<li><a href="destroy_session.php">logout</a></li><?php } ?>
                    </ul>
                </div>
             
            </div>
        </nav>
     
    </header>


    <section id="top_banner">
        <div class="banner">
            <div class="inner text-center">
                <h2>Manage Students Data</h2>
            </div>
        </div>
        <div class="page_info">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-sm-8 col-xs-6">
                        <h4>Manage Students Data</h4>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-6" style="text-align:right;">Home<span class="sep"> 	/ </span><span class="current">Manage Student</span></div>
                </div>
            </div>
        </div>

        </div>
    </section>


<html lang="en" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<link rel="stylesheet" href="css/fileinput.min.css">
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<link rel="stylesheet" href="css/style.css">


</head>

	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<link rel="stylesheet" href="css/fileinput.min.css">
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<link rel="stylesheet" href="css/style.css">


</head>

<body style="">

	
	
		
		
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<div class="panel panel-default">
							<div class="panel-heading">All Room Details</div>
							<div class="panel-body">
								<div class="row"><div class="col-sm-6"></div><div class="col-sm-6"></div><table id="zctb" class="display table table-striped table-bordered table-hover dataTable" cellspacing="0" width="100%" role="grid" aria-describedby="zctb_info" style="width: 100%;">
									<thead>
										<tr role="row"><th class="sorting_asc" tabindex="0" aria-controls="zctb" rowspan="1" colspan="1" aria-label="Sno.: activate to sort column descending" style="width: 31px;" aria-sort="ascending">Sno.</th>
										<th class="sorting" tabindex="0" aria-controls="zctb" rowspan="1" colspan="1" aria-label="Student Name: activate to sort column ascending" style="width:98px;">Student Name</th>
										<th class="sorting" tabindex="0" aria-controls="zctb" rowspan="1" colspan="1" aria-label="Reg no: activate to sort column ascending" style="width: 48px;">Reg no</th>
										<th class="sorting" tabindex="0" aria-controls="zctb" rowspan="1" colspan="1" aria-label="Contact no : activate to sort column ascending" style="width: 57px;">Contact no </th>
										<th class="sorting" tabindex="0" aria-controls="zctb" rowspan="1" colspan="1" aria-label="Staying From : activate to sort column ascending" style="width: 51px;">Email</th>
										<th class="sorting" tabindex="0" aria-controls="zctb" rowspan="1" colspan="1" aria-label="room no  : activate to sort column ascending" style="width: 36px;">percentage  </th>
							
										<th class="sorting" tabindex="0" aria-controls="zctb" rowspan="1" colspan="1" aria-label="Details: activate to sort column ascending" style="width: 44px;">Details</th>
										<th class="sorting" tabindex="0" aria-controls="zctb" rowspan="1" colspan="1" aria-label="Action: activate to sort column ascending" style="width: 44px;">Action</th></tr>
									</thead>

									<tbody>

<?php 

include "db.php";
$sql="select student.sid,student.full_name,student.par_mo,student.semail,student.percentage, room.reg_id,room.room_no from 
room inner join student on room.rid=student.sid GROUP BY Percentage DESC";
$retval=mysqli_query($con,$sql);	 
while($row=mysqli_fetch_array($retval))
{
	$sid=$row['sid'];
	$full_name=$row['full_name'];
	$regno=$row['reg_id'];
	$par_mo=$row['par_mo'];
	$semail=$row['semail'];
	$room_no=$row['percentage'];

?>									
<tr role="row" class="odd"><td class="sorting_1"><?php echo $sid; ?></td>
<td><?php echo $full_name; ?></td>
<td><?php echo $regno; ?></td>
<td><?php echo $par_mo; ?></td>
<td><?php echo $semail; ?></td>
<td><?php echo $room_no; ?></td>

<td><input type="submit" value="Accept"> &nbsp <a href ="delete_data.php?sid=<?php echo $sid; ?>">Delete</a></td>
<td><a href="javascript:void(0);"  onClick="popUpWindow('http://localhost/hit/web/debut/fp.php?sid=<?= $sid;?>');" title="View Full Details"><i class="fa fa-desktop"></i></a></td>
</tr>
<?php } ?>	
								</tbody>
								</table>
						</div>					
					</div>
				</div>
			</div>
		</div>
	</div>




	
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>




</body></html>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
   

    
</body>

</html>