<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Warden</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="scss/main.css">
    <link rel="stylesheet" href="scss/skin.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
    <script src="./script/index.js"></script>


</head>

<body id="wrapper">

    <section id="top-header">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12 top-header-links">
                    <ul class="contact_links">
                        <li><i class="fa fa-phone"></i><a href="#">+91 9574140996</a></li>
                        <li><i class="fa fa-envelope"></i><a href="#">Aakashk7190@gmail.com</a></li>
                    </ul>
                </div>
    
            </div>
        </div>
        </div>

    </section>

    <header>
        <nav class="navbar navbar-inverse">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			  </button>
                    <a class="navbar-brand" href="#">
                        <h1>Hostel</h1><span>Management System</span></a>
                </div>
                <div id="navbar" class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                       
                        <li class="active"><a href="warden.php">Warden</a></li>

                       
<?php 
session_start();						
if($_SESSION['uid']==0 || $_SESSION['uid']=="")
{
?>
      <li><a href="login.php">Sign In</a></li>
<li><a href="registration.php">Sign Up</a></li><?php }
 else 
 {	?>

<li><a href="destroy_session.php">logout</a></li><?php } ?>
                    </ul>
                </div>
              
            </div>
        </nav>
      
    </header>

    <section id="top_banner">
        <div class="banner">
            <div class="inner text-center">
                <h2>Warden Portal</h2>
            </div>
        </div>
        <div class="page_info">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-sm-8 col-xs-6">
                        <h4>Warden portal</h4>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-6" style="text-align:right;">Home<span class="sep"> 	/ </span><span class="current">warden portal</span></div>
                </div>
            </div>
        </div>

        </div>
    </section>

 </section>
 
 <section id="about-page-section-3">

<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<div class="panel panel-default">
							<div class="panel-heading">Warden </div>
							<div class="panel-body">
						
								<div class="row"><div class="col-sm-6"></div><div class="col-sm-6"></div><table id="zctb" class="display table table-striped table-bordered table-hover dataTable" cellspacing="0" width="100%" role="grid" aria-describedby="zctb_info" style="width: 100%;">
									<thead>
										<tr role="row"><th class="sorting_asc" tabindex="0" aria-controls="zctb" rowspan="1" colspan="1" aria-label="Sno.: activate to sort column descending" style="width: 31px;" aria-sort="ascending">Sr.no.</th>
										<th class="sorting" tabindex="0" aria-controls="zctb" rowspan="1" colspan="1" aria-label="Student Name: activate to sort column ascending" style="width:98px;">Name</th>
										<th class="sorting" tabindex="0" aria-controls="zctb" rowspan="1" colspan="1" aria-label="Reg no: activate to sort column ascending" style="width: 48px;">Leave date</th>
										<th class="sorting" tabindex="0" aria-controls="zctb" rowspan="1" colspan="1" aria-label="Reg no: activate to sort column ascending" style="width: 48px;">Address</th>
										<th class="sorting" tabindex="0" aria-controls="zctb" rowspan="1" colspan="1" aria-label="Reg no: activate to sort column ascending" style="width: 48px;">Reason</th>
										<th class="sorting" tabindex="0" aria-controls="zctb" rowspan="1" colspan="1" aria-label="Contact no : activate to sort column ascending" style="width: 57px;">Mobile Number</th>
										<th class="sorting" tabindex="0" aria-controls="zctb" rowspan="1" colspan="1" aria-label="Staying From : activate to sort column ascending" style="width: 51px;">Parents Number</th>
										
									</thead>
									<tbody>

 <?php include "db.php"; 
$sql="select * from leave_record ORDER BY lid";
$query=mysqli_query($con,$sql);

while($row=mysqli_fetch_array($query))
{
$lid=$row['lid'];
$fname=$row['name'];
$f_date=$row['f_date'];
$t_date=$row['t_date'];
$Address=$row['address'];
$reason=$row['reason'];
$mob_no=$row['mob_no'];
$pmobile=$row['pmobile'];
?>
<tr role="row" class="odd"><td><?php echo $lid; ?></td>
<td><?php echo $fname; ?></td>
<td><?php echo $f_date . " to " . $t_date; ?></td>
<td><?php echo $Address; ?></td>
<td><?php echo $reason; ?></td>
<td><?php echo $mob_no; ?></td>
<td><?php echo $pmobile; ?></td>

<?php } ?>
									</tbody>
                                  </table>
								</div>
							</div>
						</div>		
	</div>
	</div>
	</div>



</section>


    <section id="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                        <h4>Address</h4>
                        <hr/>
                        <p>Gyanmanjari Institute Of Technology,Survey NO.30,Near Iscon Eleven,sidsar road,Bhavnagar.
                        </p>
                        
                    </div>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                        <h4>Useful Links</h4>
                        <hr/>
                        <ul class="footer-links">
                                                        <li><a href="about.php">About Us</a></li>
                            <li><a href="features.php">Features</a></li>
                            <li><a href="facilities.php">Facilities</a></li>
               
                            <li><a href="login.php">Sign In</a></li>
                            <li><a href="registration.php">Sign Up</a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                        <h4>Community</h4>
                        <hr/>
                        <ul class="footer-links">
                            <li><a href="#">Blog</a></li>
                            <li><a href="https://facebook.com">Visit us on Facebook</a></li>
                            <li><a href="https://instagram.com">Follow us on Instagram</a></li>
                        </ul>
                    </div>
                </div>

                <v>
            </div>
        </div>


    </section>

    <section id="bottom-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12 btm-footer-links">
                    <a href="#">Privacy Policy</a>
                    <a href="#">Terms of Use</a>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12 copyright">
                    Developed by <a href="#">4 th IT Students</a> designed by <a href="#">Designing Team</a>
                </div>
            </div>
        </div>
    </section>



</body>

</html>