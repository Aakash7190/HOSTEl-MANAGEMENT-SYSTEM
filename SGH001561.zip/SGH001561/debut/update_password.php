<?php
$sid=$_GET['sid'];
include "db.php";
$newpassword=$_POST['newpassword']; 
$sql="update student_login set spass='$newpassword' where sid='$sid'";
$query=mysqli_query($con,$sql);
if($query)
{
	header("location:login.php");
}
else
{
	echo "not updated";
}
?>