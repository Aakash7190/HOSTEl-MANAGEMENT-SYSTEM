<?php
$sid=$_GET['sid'];
include "db.php";

$fname=$_POST['fname'];
$f_occup=$_POST['fOccupation'];
$dob=$_POST['date'];
$gender=$_POST['Gender'];
$blood=$_POST['blood'];
$std_mo=$_POST['MobileNumber'];
$pare_mo=$_POST['Pmobile'];
$email=$_POST['EmailID'];
$address=$_POST['Address'];
$pincode=$_POST['PinCode'];
$institute=$_POST['Collage'];
$course=$_POST['course'];
$aadhar=$_POST['Aadhar'];
$result=$_POST['result1'];
$income=$_POST['income'];
$minority=$_POST['minority'];
$admission=$_POST['admission'];
$pic=$_POST['photo'];


	$sql="UPDATE student SET full_name='$fname',f_occu='$f_occup',DOB='$dob',gender='$gender',blood_group='$blood',
										std_mo='$std_mo',par_mo='$pare_mo',semail='$email',address='$address',pincode='$pincode',
										std_clg='$institute',course='$course',aadhar_no='$aadhar' where sid='$sid'";
		
$querry=mysqli_query($con,$sql);

if($querry)
{
	header("location:room.php");
}
else 
{
	echo "not updated";
}
?>