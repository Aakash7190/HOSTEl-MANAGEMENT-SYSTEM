<!DOCTYPE html>
<html>

<head>
<script>
function SUBMIT(){
	alert("Your Form is Updated Successfully!");
}
</script>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>About</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="scss/main.css">
    <link rel="stylesheet" href="scss/skin.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
    <script src="./script/index.js"></script>

</head>

<body id="wrapper">

    <section id="top-header">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12 top-header-links">
                    <ul class="contact_links">
                        <li><i class="fa fa-phone"></i><a href="#">+91 9574140996</a></li>
                        <li><i class="fa fa-envelope"></i><a href="#">Aakashk7190@gmail.com</a></li>
                    </ul>
                </div>
            
            </div>
        </div>
        </div>

    </section>

    <header>
        <nav class="navbar navbar-inverse">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			  </button>
                    <a class="navbar-brand" href="#">
                        <h1>Hostel</h1><span>Management System</span></a>
                </div>
                <div id="navbar" class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="features.php">Features</a></li>
                        <li><a href="about.php">About</a></li>
                        <li><a href="facilities.php">Facilities</a></li>
                       
						<li class="active"><a href="#room">Admission Form</a></li>
                        
               <?php
session_start();			   
if($_SESSION['uid']==0)
{
?>
      <li><a href="login.php">Sign In</a></li>
<li><a href="registration.php">Sign Up</a></li><?php }
 else 
 {	?>

<li><a href="destroy_session.php">logout</a></li><?php } ?>
                        </ul>
                    </div>
                  
                </div>
            </div>
        </nav>
    </header>
    <section id="top_banner">
        <div class="banner">
            <div class="inner text-center">
                <h2>Admission Form</h2>
            </div>
        </div>
        <div class="page_info">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-sm-8 col-xs-6">
                        <h4>Admission Form</h4>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-6" style="text-align:right;">Home<span class="sep"> 	/ </span><span class="current">Admission Form</span></div>
                </div>
            </div>
        </div>

        </div>
    </section>


<?php 
include "db.php";
$sid=$_GET['sid'];
$sql="select * from student where sid='$sid'";
$retval=mysqli_query($con,$sql);
if($row=mysqli_fetch_array($retval))
{
	
	$sid=$row['sid'];
	$fname=$row['full_name'];
	$fOccupation=$row['f_occu'];
	$date=$row['DOB'];
	$gender=$row['gender'];
	$blood_group=$row['blood_group'];
	$std_mo=$row['std_mo'];
	$par_mo=$row['par_mo'];
	$semail=$row['semail'];
	$address=$row['address'];
	$pincode=$row['pincode'];
	$std_clg=$row['std_clg'];
	$course=$row['course'];
	$aadhar_no=$row['aadhar_no'];

?>

<section id="about-page-section-3">
<div class="row">
<div class="col-md-12">	

<div class="row">
<div class="col-md-12">
<div class="panel panel-primary">

<div class="panel-body">
<form method="post" action="update_form.php" onsubmit="SUBMIT()" class="form-horizontal">
<div class="form-group">
<label class="col-sm-4 control-label"><h4 style="color: green" align="left">PERSONAL DETAIELS</h4> </label>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">Full Name:<span style="color:red">*</span></label>
<div class="col-sm-8">
<input type="text" name="fname"  placeholder="Full Name" value="<?php echo $fname; ?>" class="form-control" required="required">
</div>
</div>


<div class="form-group">
<label class="col-sm-2 control-label">Father's Occupation:<span style="color:red">*</span></label>
<div class="col-sm-8">
<input type="text" name="fOccupation"  placeholder="Father's Occupation" value="<?php echo $fOccupation; ?>" class="form-control" required="required">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Date of Birth(DOB):<span style="color:red">*</span></label>
<div class="col-sm-8">
<input type = "date" name="date" value="<?php echo $date; ?>" required="required">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Blood Group:<span style="color:red">*</span></label>
<div class="col-sm-8">
<input type="text" name="blood"  placeholder="Blood Group" value="<?php echo $blood_group; ?>" class="form-control" required="required">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Email ID:</label>
<div class="col-sm-8">
<input type="email" name="EmailID"  placeholder="Email ID" value="<?php echo $semail; ?>" class="form-control">
</div>
</div>



<div class="form-group">
<label class="col-sm-2 control-label">Mobile Number: </label>
<div class="col-sm-8">
<input type="text" name="MobileNumber"  value="<?php echo $std_mo; ?>" placeholder="Mobile Number" maxlength="10"   class="form-control">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Guardian's Mobile Number:<span style="color:red">*</span> </label>
<div class="col-sm-8">
<input type="text" name="Pmobile" maxlength="10"  value="<?php echo $par_mo; ?>"  placeholder="Guardian's Mobile Number" class="form-control" required="required">
</div>
</div>


<div class="form-group">
<label class="col-sm-2 control-label">Gender:<span style="color:red">*</span></label>
<div class="col-sm-8">
<input type="radio" name="Gender" <?php if($gender == "Male") {echo "checked";} ?> value="Male" required="required">
Male
<input type="radio" name="Gender" <?php if($gender == "Male") {echo "checked";} ?> value="Female" required="required">
Female
</div>
</div>


<div class="form-group">
<label class="col-sm-2 control-label">Full Address :<span style="color:red">*</span></label>
<div class="col-sm-8">
<textarea  rows="5" name="Address"  class="form-control" required="required">
<?php echo $address; ?>
</textarea>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label"><h4 style="color: green" align="left">Other DETAILS </h4> </label>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Pin Code:<span style="color:red">*</span></label>
<div class="col-sm-8">
<input type="text" name="PinCode" maxlength="6"  value="<?php echo $pincode; ?>" class="form-control" required="required">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Aadhar Card:<span style="color:red">*</span></label>
<div class="col-sm-8">
<input type="text" name="Aadhar"  maxlength="12" value="<?php echo $aadhar_no; ?>" class="form-control" required="required">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Courses Applied For:<span style="color:red">*</span></label>
<div class="col-sm-8">
<select name="course">
<option <?php if($course == "Select Courses") {echo "selected";} ?> value="Select Courses">Select Courses</option>
	<option <?php if($course == "BE(Bachelor of Engeenering)") {echo "selected";} ?> value="BE(Bachelor of Engeenering)">BE(Bachelor of Engeenering)</option>
	<option <?php if($course == "BA(Bachelor of Arts)") {echo "selected";} ?> value="BA(Bachelor of Arts)">BA(Bachelor of Arts)</option>
	<option <?php if($course == "B.Sc(Bachelor of Science)") {echo "selected";} ?> value="B.Sc(Bachelor of Science)">B.Sc(Bachelor of Science)</option>
	<option <?php if($course == "MCA(Master of Computer Applications)") {echo "selected";} ?> value="MCA(Master of Computer Applications)">MCA(Master of Computer Applications)</option>
	<option <?php if($course == "BCA(Bachelor of Computer Applications)") {echo "selected";} ?> value="BCA(Bachelor of Computer Applications)">BCA(Bachelor of Computer Applications)</option>
	<option <?php if($course == "B.Com(Bachelor of Commerce)") {echo "selected";} ?> value="B.Com(Bachelor of Commerce)">B.Com(Bachelor of Commerce)</option>
	<option <?php if($course == "M.Com(Master of Commerce)") {echo "selected";} ?> value="M.Com(Master of Commerce)">M.Com(Master of Commerce)</option>
	<option <?php if($course == "M.Sc(Master of Science)") {echo "selected";} ?> value="M.Sc(Master of Science)">M.Sc(Master of Science)</option>
	<option <?php if($course == "MA(Master of Arts)") {echo "selected";} ?> value="MA(Master of Arts)">MA(Master of Arts)</option>
</select>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Institute Name:<span style="color:red">*</span></label>
<div class="col-sm-8">
<input type="text" name="Collage" value="<?php echo $std_clg; ?>" class="form-control" required="required">
</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label"><h4 style="color: green" align="left">Required Document </h4> </label>
</div>



<div class="form-group">
<label class="col-sm-2 control-label">Upload Last Result<span style="color:red">*</span></label>
 <div class="col-sm-8">
 <input type="file" name="result1"  accept=".png,.pdf,.jpg,.webp" required><br></br>
 </div>
 </div>

<div class="form-group">
<label class="col-sm-2 control-label">Upload Income certificate<span style="color:red">*</span></label>
 <div class="col-sm-8">
 <input type="file" name="income"  accept=".png,.pdf,.jpg,.webp" required><br></br>
 </div>
 </div>

<div class="form-group">
<label class="col-sm-2 control-label">Upload Minority certificate<span style="color:red">*</span></label>
 <div class="col-sm-8">
 <input type="file" name="minority"  accept=".png,.pdf,.jpg,.webp" required><br></br>
 </div>
 </div>
 
 <div class="form-group">
<label class="col-sm-2 control-label">Admission confirmation Letter<span style="color:red">*</span></label>
 <div class="col-sm-8">
 <input type="file" name="admission"  accept=".png,.pdf,.jpg,.webp" required><br></br>
 </div>
 </div>
 
 <div class="form-group">
<label class="col-sm-2 control-label">Upload your pic<span style="color:red">*</span></label>
 <div class="col-sm-8">
 <input type="file" name="photo"  accept=".png,.pdf,.jpg,.webp" required><br></br>
 </div>
 </div>




<div class="col-sm-6 col-sm-offset-4">
<input type="submit" value="Update Form" class="btn btn-default">
<input type="reset" Value="Reset"  class="btn btn-default">
</div>
</div>
</form>
</div>
</div>
</div>
</div>
</div> 
</section>
 
<?php } ?>

  <section id="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                        <h4>Address</h4>
                        <hr/>
                        <p>Gyanmanjari Institute Of Technology,Survey NO.30,Near Iscon Eleven,sidsar road,Bhavnagar.
                        </p>
                        <a href="#" class="learnmore">Learn More <i class="fa fa-caret-right"></i></a>
                    </div>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                        <h4>Useful Links</h4>
                        <hr/>
                        <ul class="footer-links">
                            <li><a href="#">About Us</a></li>
                            <li><a href="#">Features</a></li>
                            <li><a href="#">Portfolio</a></li>
                            <li><a href="#">Contact</a></li>
                            <li><a href="#">Sign In</a></li>
                            <li><a href="#">Sign Up</a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                        <h4>Community</h4>
                        <hr/>
                        <ul class="footer-links">
                            <li><a href="#">Blog</a></li>
                            <li><a href="#">Forum</a></li>
                            <li><a href="#">Free Goods</a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-12 <block></block>">
                    <div class="footer-block">
                        <h4>Recent Posts</h4>
                        <hr/>
                        <ul class="footer-links">
                            <li>
                                <a href="#" class="post">Lorem ipsum dolor sit amet</a>
                                <p class="post-date">May 25, 2017</p>
                            </li>
                            <li>
                                <a href="#" class="post">Lorem ipsum dolor sit amet</a>
                                <p class="post-date">May 25, 2017</p>
                            </li>
                            <li>
                                <a href="#" class="post">Lorem ipsum dolor sit amet</a>
                                <p class="post-date">May 25, 2017</p>
                            </li>

                        </ul>
                    </div>
                </div>
            </div>
        </div>


    </section>

    <section id="bottom-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12 btm-footer-links">
                    <a href="#">Privacy Policy</a>
                    <a href="#">Terms of Use</a>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12 copyright">
                    Developed by <a href="#">Aspire Software Solutions</a> designed by <a href="#">Designing Team</a>
                </div>
            </div>
        </div>
    </section>




</body>

</html>
