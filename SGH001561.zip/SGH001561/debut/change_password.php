<!DOCTYPE html>
<html>
<head>

<script>
function same(){
	var a = document.form.newpassword.value;
  var b = document.form.cpassword.value;

if(a == "")
	{
	  document.form.newpassword.focus();
      document.getElementById("error_box").innerHTML = "enter new password";
	  return false;
	}
if(b == "")
	{ 
	  document.form.cpassword.focus();
      document.getElementById("error_box").innerHTML = "enter confirm password";
	  return false;
	}
if(b != a)
	{
	  document.form.cpassword.focus();
      document.getElementById("error_box").innerHTML = "enter same password as above";
	  return false;	
	}
}
</script>
<?php 
include "db.php";

 ?>


    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>forget password</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="scss/main.css">
    <link rel="stylesheet" href="scss/skin.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
    <script src="./script/index.js"></script>


</head>

<body id="wrapper">

    <section id="top-header">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12 top-header-links">
                    <ul class="contact_links">
                        <li><i class="fa fa-phone"></i><a href="#">+91 9574140996</a></li>
                        <li><i class="fa fa-envelope"></i><a href="#">Aakashk7190@gmail.com</a></li>
                    </ul>
                </div>

            </div>
        </div>
        </div>

    </section>

    <header>
        <nav class="navbar navbar-inverse">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			  </button>
                    <a class="navbar-brand" href="#">
                        <h1>Hostel</h1><span>Management System</span></a>
                </div>
                <div id="navbar" class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="features.php">Features</a></li>
                        <li><a href="#about">About</a></li>
                        <li><a href="facilities.php">Facilities</a></li>
                       
                        
                        <li class="active"><a href="login.php">Sign In</a></li>
                        <li><a href="registration.php">Sign Up</a></li>
                    </ul>
                </div>
             
            </div>
        </nav>
    </header>

    <section id="top_banner">
        <div class="banner">
            <div class="inner text-center">
                <h2>Student Login</h2>
            </div>
        </div>
        <div class="page_info">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-sm-8 col-xs-6">
                        <h4>Forgot Password?</h4>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-6" style="text-align:right;">Home<span class="sep"> 	/ </span><span class="current"> change password</span></div>
                </div>
            </div>
        </div>

        </div>
    </section>





<style>


</style>

	
	<div class="ts-main-content">
		
		<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">
					
					<div class="row">
							<div class="col-md-6">
								<div class="panel panel-default">
									<div class="panel-heading"><b></b></div>
									<div class="panel-body">
										<form name="form" action="update_password.php" method="post" class="form-horizontal">
											<div class="form-group">
											<div style="color: red;"><label id="error_box" ></label></div>
												<label class="col-sm-4 control-label">New Password</label>
												
												<div class="col-sm-8">
											<input type="text" class="form-control" name="newpassword" id="password" required>
												</div>
											</div>
                                     <div class="form-group">
									<label class="col-sm-4 control-label">Confirm Password</label>
									<div class="col-sm-8">
				                    <input type="password" name="cpassword" class="form-control" required="required" id="Confirm_password" >
												</div>
												</br>
											</div>
											<div class="col-sm-8 col-sm-offset-2">
											<input type="reset" value="Cancel" class="btn btn-default">
													<input type="submit" onclick="return same()" value="Change Password" class="btn btn-primary" >
                                               </div>
											   </div>
										</form>

					</div>
		</div>								
</div>

									</div>
								</div>
								</div>
								</div>
								</div>
								</div>
								</div>
								</div>
							
    <section id="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                        <h4>Address</h4>
                        <hr/>
                        <p>Gyanmanjari Institute Of Technology,Survey NO.30,Near Iscon Eleven,sidsar road,Bhavnagar.
                        </p>
                        
                    </div>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                        <h4>Useful Links</h4>
                        <hr/>
                        <ul class="footer-links">
                                                        <li><a href="about.php">About Us</a></li>
                            <li><a href="features.php">Features</a></li>
                            <li><a href="facilities.php">Facilities</a></li>
               
                            <li><a href="login.php">Sign In</a></li>
                            <li><a href="registration.php">Sign Up</a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                        <h4>Community</h4>
                        <hr/>
                        <ul class="footer-links">
                            <li><a href="#">Blog</a></li>
                            <li><a href="#">Visit us on Facebook</a></li>
                            <li><a href="#">Follow us on Instagram</a></li>
                        </ul>
                    </div>
                </div>

                
            </div>
        </div>


    </section>

    <section id="bottom-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12 btm-footer-links">
                    <a href="#">Privacy Policy</a>
                    <a href="#">Terms of Use</a>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12 copyright">
                    Developed by <a href="#">4 th IT Students</a> designed by <a href="#">Designing Team</a>
                </div>
            </div>
        </div>
    </section>


 


</body>

</html>