<?php 
session_start();
$_SESSION['uid'] =0;
$_SESSION['pid'] =0;
$_SESSION['username']="";
$_SESSION['password']="";
header("location:index.php");
?>