<?php
include "db.php";
$id=$_POST["rid"];
$regno=$_POST['regno'];
$room_no=$_POST['room_no'];
$par_mo=$_POST['par_mo'];



	$sql="insert into room (reg_id,room_no,par_mo)
		values('$regno','$room_no','$par_mo')";
$retval=mysqli_query($con,$sql);
header("location:faq.php");
//if($retval)
{
	//echo "inserted successfully.";
}
//else
{
	//echo "not inserted successfully.";
}

?>