<!DOCTYPE html>
<html>

<head>
<script>
function SUBMIT(){
	alert("Your Form is Submitted Successfully!");
}
</script>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>About</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="scss/main.css">
    <link rel="stylesheet" href="scss/skin.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
    <script src="./script/index.js"></script>

</head>

<body id="wrapper">

    <section id="top-header">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12 top-header-links">
                    <ul class="contact_links">
                        <li><i class="fa fa-phone"></i><a href="#">+91 9574140996</a></li>
                        <li><i class="fa fa-envelope"></i><a href="#">Aakashk7190@gmail.com</a></li>
                    </ul>
                </div>
            
            </div>
        </div>
        </div>

    </section>

    <header>
        <nav class="navbar navbar-inverse">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			  </button>
                    <a class="navbar-brand" href="#">
                        <h1>Hostel</h1><span>Management System</span></a>
                </div>
                <div id="navbar" class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="features.php">Features</a></li>
                        <li><a href="about.php">About</a></li>
                        <li><a href="facilities.php">Facilities</a></li>
                       
						<?php 
session_start();						
if($_SESSION['uid']==0| $_SESSION['uid']=="")
{
?>
      <li><a href="login.php">Sign In</a></li>
<li><a href="registration.php">Sign Up</a></li><?php }
else if($_SESSION['uid']==1 || $_SESSION['uid']=="")
 {	?>
<li><a href="wardenmessage.php">Take Leave</a></li>
<li class="active"><a href="hh.php">Admission Form</a></li>
<li><a href="destroy_session.php">Logout</a></li>
<?php }

else if($_SESSION['uid']==2 || $_SESSION['uid']=="")
{ ?>

<li><a href="slideboard.php">Activities</a></li>
<li><a href="contact.php">Contact</a></li>
<li><a href="destroy_session.php">logout</a></li>
	
<?php 
}
?>
                        </ul>
                    </div>
                    
                </div>
            </div>
        </nav>
    </header>
    <section id="top_banner">
        <div class="banner">
            <div class="inner text-center">
                <h2>Admission Form</h2>
            </div>
        </div>
        <div class="page_info">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-sm-8 col-xs-6">
                        <h4>Admission Form</h4>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-6" style="text-align:right;">Home<span class="sep"> 	/ </span><span class="current">Admission Form</span></div>
                </div>
            </div>
        </div>

        </div>
    </section>

<section id="about-page-section-3">
<div class="row">
<div class="col-md-12">	

<div class="row">
<div class="col-md-12">
<div class="panel panel-primary">

<div class="panel-body">
<form method="post" action="insert_record.php" onsubmit="SUBMIT()" class="form-horizontal">
<div class="form-group">
<label class="col-sm-4 control-label"><h4 style="color: green" align="left">PERSONAL DETAIELS</h4> </label>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">Full Name:<span style="color:red">*</span></label>
<div class="col-sm-8">
<input type="text" name="fname"  placeholder="Full Name" class="form-control" required="required">
</div>
</div>


<div class="form-group">
<label class="col-sm-2 control-label">Father's Occupation:<span style="color:red">*</span></label>
<div class="col-sm-8">
<input type="text" name="fOccupation"  placeholder="Father's Occupation" class="form-control" required="required">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Date of Birth(DOB):<span style="color:red">*</span></label>
<div class="col-sm-8">
<input type = "date" name="date" required="required">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Blood Group:<span style="color:red">*</span></label>
<div class="col-sm-8">
<input type="text" name="blood"  placeholder="Blood Group" class="form-control" required="required">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Email ID:</label>
<div class="col-sm-8">
<input type="email" name="EmailID"  placeholder="Email ID" class="form-control">
</div>
</div>



<div class="form-group">
<label class="col-sm-2 control-label">Mobile Number: </label>
<div class="col-sm-8">
<input type="text" name="MobileNumber"  placeholder="Mobile Number" maxlength="10"   class="form-control">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Guardian's Mobile Number:<span style="color:red">*</span> </label>
<div class="col-sm-8">
<input type="text" name="Pmobile" maxlength="10"   placeholder="Guardian's Mobile Number" class="form-control" required="required">
</div>
</div>


<div class="form-group">
<label class="col-sm-2 control-label">Gender:<span style="color:red">*</span></label>
<div class="col-sm-8">
<input type="radio" name="Gender" value="Male" required="required">
Male
<input type="radio" name="Gender" value="Female" required="required">
Female
</div>
</div>


<div class="form-group">
<label class="col-sm-2 control-label">Full Address :<span style="color:red">*</span></label>
<div class="col-sm-8">
<textarea  rows="5" name="Address"   class="form-control" required="required">

</textarea>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label"><h4 style="color: green" align="left">Other DETAILS </h4> </label>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Pin Code:<span style="color:red">*</span></label>
<div class="col-sm-8">
<input type="text" name="PinCode" maxlength="6"   class="form-control" required="required">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Aadhar Card:<span style="color:red">*</span></label>
<div class="col-sm-8">
<input type="text" name="Aadhar"  maxlength="12" class="form-control" required="required">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Courses Applied For:<span style="color:red">*</span></label>
<div class="col-sm-8">
<select name="course">
<option>Select Courses</option>
	<option>BE(Bachelor of Engeenering)</option>
	<option>BA(Bachelor of Arts)</option>
	<option>B.Sc(Bachelor of Science)</option>
	<option>MCA(Master of Computer Applications)</option>
	<option>BCA(Bachelor of Computer Applications)</option>
	<option>B.Com(Bachelor of Commerce)</option>
	<option>M.Com(Master of Commerce)</option>
	<option>M.Sc(Master of Science)</option>
	<option>MA(Master of Arts)</option>
</select>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Percentage:<span style="color:red">*</span></label>
<div class="col-sm-8">
<input type="text" name="percentage"  maxlength="5" class="form-control" required="required">
</div>
</div>


<div class="form-group">
<label class="col-sm-2 control-label">Institute Name:<span style="color:red">*</span></label>
<div class="col-sm-8">
<input type="text" name="Collage"   class="form-control" required="required">
</div>
</div>

<div class="form-group">
<label class="col-sm-3 control-label"><h4 style="color: green" align="left">Required Document </h4> </label>
</div>



<div class="form-group">
<label class="col-sm-2 control-label">Upload Last Result<span style="color:red">*</span></label>
 <div class="col-sm-8">
 <input type="file" name="result1"  accept=".png,.pdf,.jpg,.webp" required><br></br>
 </div>
 </div>

<div class="form-group">
<label class="col-sm-2 control-label">Upload Income certificate<span style="color:red">*</span></label>
 <div class="col-sm-8">
 <input type="file" name="income"  accept=".png,.pdf,.jpg,.webp" required><br></br>
 </div>
 </div>

<div class="form-group">
<label class="col-sm-2 control-label">Upload Minority certificate<span style="color:red">*</span></label>
 <div class="col-sm-8">
 <input type="file" name="minority"  accept=".png,.pdf,.jpg,.webp" required><br></br>
 </div>
 </div>
 
 <div class="form-group">
<label class="col-sm-2 control-label">Admission confirmation Letter<span style="color:red">*</span></label>
 <div class="col-sm-8">
 <input type="file" name="admission"  accept=".png,.pdf,.jpg,.webp" required><br></br>
 </div>
 </div>
 
 <div class="form-group">
<label class="col-sm-2 control-label">Upload your pic<span style="color:red">*</span></label>
 <div class="col-sm-8">
 <input type="file" name="photo"  accept=".png,.pdf,.jpg,.webp" required><br></br>
 </div>
 </div>




<div class="col-sm-6 col-sm-offset-4">
<input type="submit" value="Submit Form" class="btn btn-default">
<input type="reset" Value="Reset" class="btn btn-default">
</div>
</div>
</form>
</div>
</div>
</div>
</div>
</div> 
</section>

    <section id="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                        <h4>Address</h4>
                        <hr/>
                        <p>Gyanmanjari Institute Of Technology,Survey NO.30,Near Iscon Eleven,sidsar road,Bhavnagar.
                        </p>
                        
                    </div>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                        <h4>Useful Links</h4>
                        <hr/>
                        <ul class="footer-links">
                                                        <li><a href="about.php">About Us</a></li>
                            <li><a href="features.php">Features</a></li>
                            <li><a href="facilities.php">Facilities</a></li>
               
                            <li><a href="login.php">Sign In</a></li>
                            <li><a href="registration.php">Sign Up</a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <div class="footer-block">
                        <h4>Community</h4>
                        <hr/>
                        <ul class="footer-links">
                            <li><a href="#">Blog</a></li>
                            <li><a href="#">Visit us on Facebook</a></li>
                            <li><a href="#">Follow us on Instagram</a></li>
                        </ul>
                    </div>
                </div>

               
            </div>
        </div>


    </section>

    <section id="bottom-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12 btm-footer-links">
                    
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12 copyright">
                    Developed by <a href="#">4th IT Students</a> designed by <a href="#">Designing Team</a>
                </div>
            </div>
        </div>
    </section>




</body>

</html>