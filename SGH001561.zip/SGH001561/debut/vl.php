<?php
include "db.php";
$uname = $_POST['uname'];
$pass = $_POST['pass'];
$q = "select count(sid) from student_login where semail = '".$uname."' and spass='".$pass."'";
$r = mysqli_query($con,$q);
$row = mysqli_fetch_array($r);

$q1 = "select count(aid) from admin where username = '".$uname."' and apass='".$pass."'";
$r1 = mysqli_query($con,$q1);
$row1 = mysqli_fetch_array($r1);

$q2 = "select count(rid) from room where reg_id= '".$uname."' and par_mo='".$pass."'" ;
$r2 = mysqli_query($con,$q2);
$row2 = mysqli_fetch_array($r2);

$q3 = "select count(wid) from warden where username= '".$uname."' and wpass='".$pass."'" ;
$r3 = mysqli_query($con,$q3);
$row3 = mysqli_fetch_array($r3);

 intval($row[0]);
if(intval($row[0])==1)
{
session_start();
$_SESSION['uid']=1;
header("Location:index.php");
}


elseif(intval($row1[0])==1)
{
session_start();
$_SESSION['uid']=1;
header("Location:admintable.php");
}


elseif(intval($row2[0])==1)
{
session_start();
$_SESSION['uid']=2;
header("Location:contact.php");
}


elseif(intval($row3[0])==1)
{
session_start();
$_SESSION['uid']=1;
header("Location:warden.php");
}
else
{
	header("location:login.php");
}
?> 	

   
